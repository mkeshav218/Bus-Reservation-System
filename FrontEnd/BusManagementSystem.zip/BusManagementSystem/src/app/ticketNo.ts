export class BookedTiketSearch{
    ticketNo: number; 
}