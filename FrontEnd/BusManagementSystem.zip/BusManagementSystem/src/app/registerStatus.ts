export class RegisterStatus{
    status: String;
    message: String;
}