import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authorized-user',
  templateUrl: './authorized-user.component.html',
  styleUrls: ['./authorized-user.component.css']
})
export class AuthorizedUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
