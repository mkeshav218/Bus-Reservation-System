
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-bus',
  templateUrl: './search-bus.component.html',
  styleUrls: ['./search-bus.component.css']
})
export class SearchBusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
