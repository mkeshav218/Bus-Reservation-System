export class Search{
src:string;
dest:string;
fromTime:string;
toTime:string;
typeOfUser:string;
}
