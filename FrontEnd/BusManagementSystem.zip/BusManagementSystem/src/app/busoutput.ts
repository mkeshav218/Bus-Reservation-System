export  class BusOutput{
    pathNo:String;
    source:String;
    destination:String;
    routeNo:String;
    distance:String;
    startTime:String;
    reachTime:String;
    fare:String;
    busNo:String;
    busName:String;
    busType:String;
    busStatus:String;
    static busNo:String;
}