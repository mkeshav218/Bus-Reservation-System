export class ForgotPassword{
    email:String;
}