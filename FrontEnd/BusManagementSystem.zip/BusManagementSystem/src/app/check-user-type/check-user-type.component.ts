import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-user-type',
  templateUrl: './check-user-type.component.html',
  styleUrls: ['./check-user-type.component.css']
})
export class CheckUserTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
