export class CancelTicket{
    ticketNo:number;
    email:String;
}