export class Available{

    busNo:Number;
    doj:String;
    src:String;
    dest:String;

}