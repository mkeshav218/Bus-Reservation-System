export class allBook{
    seat:number[];
}