export class Reserve{
    doj:string;
    seatNo:string;
    pathNo:string;
    email:string;
    phone:string;
}