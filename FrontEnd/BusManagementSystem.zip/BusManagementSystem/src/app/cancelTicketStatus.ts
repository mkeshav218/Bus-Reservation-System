export class CancelTicketStatus{
    message:String;
    status:String;
}