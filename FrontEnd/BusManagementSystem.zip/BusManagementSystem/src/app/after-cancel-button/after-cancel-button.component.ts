import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-after-cancel-button',
  templateUrl: './after-cancel-button.component.html',
  styleUrls: ['./after-cancel-button.component.css']
})
export class AfterCancelButtonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
