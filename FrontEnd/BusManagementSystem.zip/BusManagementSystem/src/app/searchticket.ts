export class SearchTicket{  
    bookingDate: String;
    dateOfJourney: String;
    ticketNo: String;
    seatNo: String;
    busNo: String;
    source: String;
    destination: String;
    fare: String;
    startTime: String;
    reachTime: String;
}