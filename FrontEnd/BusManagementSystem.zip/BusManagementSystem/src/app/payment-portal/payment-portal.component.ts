import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-portal',
  templateUrl: './payment-portal.component.html',
  styleUrls: ['./payment-portal.component.css']
})
export class PaymentPortalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
