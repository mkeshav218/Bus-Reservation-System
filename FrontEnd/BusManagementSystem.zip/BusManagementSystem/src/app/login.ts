export class Login{
    emailId:string;
    password:string;
}